package com.polites.android.example;

import android.os.Bundle;

public class ScaleTypeCenterInside extends ExampleActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
    	super.onCreate(savedInstanceState);
    	setContentView(R.layout.scale_type_inside);
    }
}